# clnc 免流工具

基于 [clnc](https://github.com/esrrhs/pingtunnel) 内核的轻量级免流代理工具，适用于已 root 的 Android 设备（Magisk/面具环境）。通过 TUN 虚拟网卡和 iptables 规则，将设备流量按配置的模式进行转发和混淆，实现定向免流。

> **注意**：免流涉及运营商套餐规则，使用前请确认自己的套餐是否支持，自行承担相关风险。

## 项目结构

```
clnc/
├── config.ini              # 主配置文件（模式、自启、放行等）
├── 开启.sh                  # 启动脚本
├── 关闭.sh                  # 停止脚本
├── 检测.sh                  # 状态检测脚本
├── 百度直连.conf            # 百度直连 + CNS 混淆模式配置
├── 百度直连2.conf           # 百度直连备用模式配置
├── 彩信直连.conf            # 彩信（MMS）直连模式配置
└── Core/
    ├── clnc                # clnc 代理核心二进制
    ├── CuteBi              # 管理脚本（启停、检测、iptables 规则）
    ├── MLBox               # 网络检测工具（DNS/HTTP/HTTPS/UDP 测试）
    ├── busybox             # busybox 工具集
    └── clnc.pid            # 运行中的进程 PID 文件
```

## 使用方法

在终端（adb shell / Termux）中进入项目目录执行：

```sh
# 启动
sh 开启.sh

# 停止
sh 关闭.sh

# 查看运行状态 / 联网检测
sh 检测.sh
```

启动后脚本会自动完成：创建 TUN 设备 → 清理旧规则 → 配置 iptables → 启动 clnc → 设置路由 → 输出状态检查结果。

## 主配置说明（config.ini）

| 配置项 | 说明 |
|--------|------|
| `modeName` | 当前使用的模式名，对应同目录下的 `.conf` 文件（可省略后缀），如 `'百度直连'` |
| `clnc_dns` | clnc 启动时解析域名用的 DNS，一般留空智能选择，域名污染时自定义 |
| `autoStart` | 开机自启（`1` 开启，仅 Magisk 版生效） |
| `allowWifi` | WiFi 环境下放行不走代理（`1` 放行） |
| `allowIPs` | 放行 IP 列表，空格分隔，支持 CIDR，如 `'10.0.0.0/8 8.8.8.8'` |
| `kernelOpt` | 内核选项：`allow` 放行 / `deny` 禁网 / `proxy` 代理 |
| `ipv6Opt` | IPv6 选项：`allow` 放行 / `deny` 禁网 / `proxy` 代理 |
| `localAllowApps` | 全局放行的应用（填 uid 或包名，空格分隔） |
| `localUdpAllowApps` | 放行 UDP 的应用 |
| `localTcpAllowApps` | 放行 TCP 的应用 |
| `shareAllow` | 热点共享全局放行（`1` 开启） |
| `shareAllowUdp` | 热点共享放行 UDP（`1` 开启） |
| `shareAllowTcp` | 热点共享放行 TCP（`1` 开启） |
| `onlyProxyShare` | 只代理共享数据、本机放行（`1` 开启，适合只做共享的老设备） |

## 模式配置说明

各 `.conf` 文件是 clnc 的规则配置，关键变量在文件开头的 `variables` 块中，按需修改：

| 文件 | 用途 | 需要修改的变量 |
|------|------|----------------|
| `百度直连.conf` | 百度直连 + CNS（头条）混淆 | `dst_ip`（百度直连 IP）、`cns_server`、`cns_passwd` |
| `百度直连2.conf` | 百度直连备用模式 | `Ml_iP`（直连 IP）、`cns_server`、`cns_passwd`、`Ml_Host`（混淆 Host） |
| `彩信直连.conf` | 彩信（MMS）直连 | `m_destAddr`（MMS 代理地址）、`fake_host` |

### 可用的免流混淆 Host 参考

在 `百度直连2.conf` 注释中列出了常见的混淆域名：

```
合作A混淆：
  m.toutiao.com / dm.toutiao.com
  v9-cdn-tos.ppxvod.com
  pull-f5.flive.douyincdn.com（抖音）
  static-d.iqiyi.com（爱奇艺）

阿里混淆：
  gw.alicdn.com
```

不同地区、不同运营商的直连 IP 也列在注释中（如联通苏州 `157.0.146.158`、南京 `153.3.237.117` 等），根据自己所在地区选择替换。

## 运行要求

- 已 root 的 Android 设备（推荐 Magisk）
- 支持 TUN 的内核（`/dev/net/tun`）
- iptables / ip6tables 可用
- 通过 adb shell 或 Termux 等终端执行脚本

## 端口说明

clnc 默认监听以下本地端口：

| 端口 | 用途 |
|------|------|
| `6650` | TCP 全局监听 / UDP TPROXY |
| `6653` | DNS 监听 |
| `1081` | SOCKS5 监听（供其他应用手动连接） |

## 常见问题

**启动后没有网络？**
先运行 `sh 检测.sh` 查看 DNS/HTTP/HTTPS/UDP 四项检测结果。DNS 失败说明当前 IP 不可用，需要更换 `.conf` 中的直连 IP。

**VoLTE 不可用？**
把 `config.ini` 中的 `ipv6Opt` 改为 `allow`，或直接关闭 VoLTE。

**只想代理热点共享的设备？**
设置 `onlyProxyShare='1'`，本机流量会被放行。
